version '1.1.0'


client_scripts {
    '@es_extended/locale.lua',
	'locales/pl.lua',
    'config.lua',
    'client/main.lua'
}

server_scripts {
    '@es_extended/locale.lua',
	'locales/pl.lua',
    'config.lua',
    'server/main.lua'
}
