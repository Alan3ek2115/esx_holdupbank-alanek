Config = {}
Config.Locale = 'pl'

Config.PoliceNumberRequired = 7
Config.TimerBeforeNewRob = 172800


Banks = {
    ["blainecounty_savings"] = {
        position = { ['x'] = 3610.03, ['y'] = 3728.45, ['z'] = 29.69 },
        reward = math.random(1000000,1500000),
        nameofbank = "Humane labs",
        secondsRemaining = 1, -- seconds
        lastrobbed = 0,
	humane = ""
    },
	["fleecahighway_savings"] = {
        position = { ['x'] = -2957.7, ['y'] = 481.63, ['z'] = 15.7 },
        reward = math.random(190000,290000),
        nameofbank = "Autostrada \"Poza miastem\"",
        secondsRemaining = 1, -- seconds
        lastrobbed = 0,
	humane = ""
    },
    ["blainecounty"] = {
		position = { ['x'] = -107.06505584717, ['y'] = 6474.8012695313, ['z'] = 31.62670135498 },
        reward = math.random(300000,470000),
        nameofbank = "blaine county",
        secondsRemaining = 1, -- seconds
        lastrobbed = 0,
	humane = ""
    },
    ["skarbiec"] = {
        position = { ['x'] = 255.983529, ['y'] = 226.072116, ['z'] = 101.883456 },
        reward = math.random(300000,470000),
        nameofbank = "Pacyfic \"Centrum Miasta\"",
        secondsRemaining = 1, -- seconds
        lastrobbed = 0,
	humane = ""
    },
	["fleecacentre_savings"] = {
        position = { ['x'] =  147.04908752441, ['y'] = -1044.9448242188, ['z'] = 29.36802482605},
        reward = math.random(190000,290000),
        nameofbank = "Fleeca \"Centrum Miasta\"",
        secondsRemaining = 1, -- seconds
        lastrobbed = 0,
	    humane = ""
    }
}
